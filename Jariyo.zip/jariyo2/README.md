# Timed Cards Opening

A Pen created on CodePen.io. Original URL: [https://codepen.io/r3dtomato/pen/BaEOzmr](https://codepen.io/r3dtomato/pen/BaEOzmr).

