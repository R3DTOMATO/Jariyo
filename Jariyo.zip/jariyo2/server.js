const express = require("express");
const app = express();


app.use("/",function(req,res){
    res.sendFile(__dirname + '/index.html');
});

app.listen(8080);

const websocket = require('ws');

const wss = new websocket.Server({port:8081});
const io = new websocket.Server({port:8082});



wss.on('connection', (ws)=>{
    ws.on('message',(msg)=>{
        if(msg=='start')
            {
                console.log('start');
            }
        if(msg=='NoChair')
            {
               console.log('모든자리에사람이 없습니다.');
               io.emit('None')          
            };
        if(msg=='FrontChair')
                {
                   console.log('앞자리에는 사람이 있습니다.');
                   io.emit('FChair')          
                };
        if(msg=='BehindChair')
                {
                    console.log('뒷자리에는 사람이 있습니다.');
                    io.emit('BChair')          
                };
        if(msg=='All')
            {
                console.log('모든자리에는 사람이 있습니다.');
                io.emit('AChair');
            };
        if(msg=='NoChair2')
            {
                console.log('모든자리에사람이 없습니다.');
                io.emit('None2')          
            };
        if(msg=='FrontChair2')
                    {
                       console.log('앞자리에는 사람이 있습니다.');
                       io.emit('FChair2')          
                    };
        if(msg=='BehindChair2')
                    {
                        console.log('뒷자리에는 사람이 있습니다.');
                        io.emit('BChair2')          
                    };
        if(msg=='All2')
                {
                    console.log('모든자리에는 사람이 있습니다.');
                    io.emit('AChair2');
                };
        if(msg=='success')
            {
                console.log('success');
            }
    });
});



io.on('connection',(ios)=>{
    io.on('None',()=>{
        ios.send('No');
    })
    
    io.on('FChair',()=>{
        ios.send('Front')
    })
    io.on('BChair',()=>{
        ios.send('Behind')
    })
    io.on('AChair',()=>{
        ios.send('All')
    })
    io.on('None2',()=>{
        ios.send('No2');
    })
    
    io.on('FChair2',()=>{
        ios.send('Front2')
    })
    io.on('BChair2',()=>{
        ios.send('Behind2')
    })
    io.on('AChair2',()=>{
        ios.send('All2')
    })
})

